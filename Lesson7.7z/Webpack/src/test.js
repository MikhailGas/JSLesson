
function testFunction(){
    console.log('Hello, i am test');
};

export default testFunction;