import testFunction from './test.js';

testFunction();